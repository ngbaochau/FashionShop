﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public  class SizeModel
    {
        public int MaSize {  get; set; }
        public string TenSize { get; set; }
        public string Ghichu { get; set; }
    }
}
