﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class ThongKeDoanhThuModel
    {
        public int SoDonHang {  get; set; }
        public Decimal DoanhThu {  get; set; }
        public int SoLuongSP {  get; set; }
    }
}
