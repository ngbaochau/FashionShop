﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class GetAllSizeModel
    {
        //public string TenSanPham { set; get; }
        public int MaSize {  get; set; }
        public string TenSize {  set; get; }
    }
}
